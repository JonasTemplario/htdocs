# Guia para fazer o PHP: Garagem 70 (sem JavaScript)

O site usa só **HTML, CSS e PHP**. O ViaCEP é consultado **pelo PHP com cURL**, igual ao modelo da aula.

As páginas de formulário e listagem ficam em `templates/` como **modelos com marcadores** `{{...}}`.
O PHP carrega o modelo com `file_get_contents()` e troca os marcadores com `str_replace()`, o mesmo esquema do `#resultado` da aula.

---

## Estrutura final (depois que você criar os PHP)

```
garagem70/
├── index.html              (pronto: página inicial)
├── cadastro.php            ← VOCÊ: mostra o formulário vazio
├── buscar_cep.php          ← VOCÊ: consulta o ViaCEP e devolve o form preenchido
├── salvar.php              ← VOCÊ: valida e grava no JSON
├── usuarios.php            ← VOCÊ: lista e busca os cadastrados
├── templates/
│   ├── cadastro.html       (pronto: modelo do formulário)
│   └── usuarios.html       (pronto: modelo da listagem)
├── css/style.css           (pronto)
└── dados/usuarios.json     (começa com [])
```

## Como funciona o fluxo

```
index.html → cadastro.php (form vazio)
                 │
                 ├─ botão "Buscar CEP" → buscar_cep.php → cURL no ViaCEP → form com endereço
                 │                                                  │
                 └─ botão "Cadastrar"  → salvar.php ←───────────────┘
                                             │ grava
                                             ▼
                                   dados/usuarios.json → usuarios.php (tabela)
```

**Os dois botões** estão no mesmo `<form>`. O "Cadastrar" usa o `action="salvar.php"`.
O "Buscar CEP" tem `formaction="buscar_cep.php"`, que é HTML puro e manda o form para outro arquivo.
Como os dois enviam **todos os campos** por POST, o `buscar_cep.php` consegue devolver o nome, CPF etc. que a pessoa já tinha digitado.

---

## A regra de ouro dos marcadores

O `templates/cadastro.html` tem estes marcadores:

`{{mensagem}}` `{{status_cep}}` `{{nome}}` `{{cpf}}` `{{email}}` `{{telefone}}` `{{cep}}` `{{endereco}}` `{{numero}}` `{{complemento}}` `{{bairro}}` `{{cidade}}` `{{estado}}`

**Toda vez** que o PHP mostrar esse formulário, ele precisa trocar **todos** os marcadores, nem que seja por `""` (vazio).
Se esquecer um, aparece `{{nome}}` escrito dentro do campo. É o mesmo que vocês fizeram com `#resultado` → `""`.

(Os marcadores também aparecem nos comentários `<!-- -->` do modelo, como explicação. O `str_replace` vai trocar lá também, e isso não tem problema nenhum.)

💡 Dica: o `str_replace` aceita **arrays**. Pesquise como passar uma lista de marcadores e uma lista de valores de uma vez só. Fica bem mais curto que 13 linhas de `str_replace`.

---

## 1. cadastro.php (o mais fácil; comece por ele)

É praticamente o **segundo arquivo do modelo da aula**:
1. Carregar `templates/cadastro.html` numa variável.
2. Trocar todos os marcadores por vazio. No `{{status_cep}}` você pode colocar um texto tipo "Digite o CEP e clique em Buscar CEP."
3. `echo` no resultado.

✅ Teste: abra `http://localhost/garagem70/cadastro.php`. O formulário deve aparecer limpo, sem nenhum `{{` visível.

---

## 2. buscar_cep.php (baseado no primeiro arquivo da aula)

1. Verificar se o `cep` veio (`isset`). Se não veio, volte para o `cadastro.php`.
2. Pegar **todos** os campos do `$_POST` (não só o CEP), para devolver o que a pessoa já tinha digitado.
3. **Limpar o CEP**: deixar só números. Pesquise `preg_replace` com `/\D/`.
   Se não tiver 8 dígitos, mostre o form com mensagem de erro no `{{status_cep}}` **sem** chamar a API.
4. Montar a URL e fazer o cURL (igual à aula).
5. `json_decode($resposta, true)`.
6. **Atenção:** quando o CEP não existe, o ViaCEP devolve `{"erro": "true"}`. Verifique com `isset($dados['erro'])` e mostre "CEP não encontrado".
7. Carregar o template e trocar os marcadores:
   - `{{endereco}}` ← `$dados['logradouro']`
   - `{{bairro}}` ← `$dados['bairro']`
   - `{{cidade}}` ← `$dados['localidade']`
   - `{{estado}}` ← **`$dados['uf']`** (no modelo da aula estava `estado`, que traz o nome completo, ex. "São Paulo". O campo do form é para a sigla de 2 letras, ex. "SP".)
   - os outros (`{{nome}}`, `{{cpf}}`...) ← o que veio do `$_POST`
   - `{{status_cep}}` ← "Endereço encontrado! Agora informe o número."
8. `echo`.

⚠️ No modelo da aula tem um erro pequeno: `"<a href='index.php>"` está sem a aspa simples de fechamento depois de `index.php`.

✅ Teste: digite um nome, um CEP (ex. `01310100`), clique em Buscar CEP. O endereço deve aparecer **e o nome deve continuar lá**.

---

## 3. salvar.php

1. Se não veio por POST, redirecione para `cadastro.php`. Pesquise `$_SERVER['REQUEST_METHOD']`, `header('Location: ...')`, `exit`.
2. Pegar os campos e limpar espaços (`trim`). Guardar CPF só com números.
3. **Validar** (o `required` do HTML ajuda, mas o PHP também precisa validar):
   - obrigatórios não vazios: `empty`
   - e-mail: `filter_var(..., FILTER_VALIDATE_EMAIL)`
   - CPF com 11 dígitos: `strlen`
   - cidade preenchida (prova de que o CEP foi buscado)
   Se der erro: **carregue o template de novo** com os dados preenchidos e o erro no `{{mensagem}}`. Assim a pessoa não perde o que digitou.
4. Ler o JSON: `file_get_contents` + `json_decode(..., true)`.
5. Não deixar CPF repetido: `foreach` comparando (vale ponto extra).
6. Montar o array associativo do novo usuário. Extras: `id` (`uniqid`) e data (`date`).
7. Adicionar (`$lista[] = $novo;`) e gravar: `json_encode` com `JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE` + `file_put_contents`.
8. Mostrar o form limpo com `<div class="alerta sucesso">Cadastro realizado!</div>` no `{{mensagem}}`, ou redirecionar para `usuarios.php`.

✅ Teste: cadastre alguém e abra `dados/usuarios.json`.

---

## 4. usuarios.php

1. Ler o JSON.
2. Pegar a busca: `$_GET['busca'] ?? ''`.
3. Se tiver busca, filtrar: para cada usuário, ver se o termo aparece no nome, CPF ou cidade (`stripos`).
4. Montar a variável `$linhas` com um `foreach`, **concatenando** um `<tr>...</tr>` por usuário (o formato está comentado no topo de `templates/usuarios.html`).
5. Se não sobrou ninguém, `$linhas` recebe a linha "Nenhum sócio cadastrado ainda".
6. Carregar `templates/usuarios.html` e trocar `{{linhas}}`, `{{total}}` (`count`) e `{{busca}}`.

---

## 5. Segurança: htmlspecialchars

Sempre que for colocar algo que **o usuário digitou** dentro do HTML (nos `{{...}}` do form ou nas `<td>` da tabela), passe por `htmlspecialchars()`.
Sem isso, alguém que cadastrar o nome `"><script>...` quebra a página. É uma boa coisa para mencionar na apresentação.

---

## 6. Erros comuns

| Problema | Causa provável |
|---|---|
| Aparece o código PHP na tela | Abriu sem `localhost` (XAMPP ou `php -S localhost:8000`) |
| Aparece `{{nome}}` no campo | Esqueceu de trocar algum marcador |
| cURL não retorna nada | Extensão curl desligada no `php.ini` (XAMPP: tire o `;` de `extension=curl`) ou sem internet |
| Erro de certificado SSL no cURL (XAMPP no Windows) | Pesquise `CURLOPT_SSL_VERIFYPEER`, mas saiba explicar por que está usando |
| `json_decode` retorna `null` | `usuarios.json` vazio; ele precisa ter `[]` |
| Acentos viram `ã` | Faltou `JSON_UNESCAPED_UNICODE` |
| "Undefined array key" | O nome no `$_POST` está diferente do `name` do HTML |

---

## 7. Explicação do projeto (para a entrega)

- **Tema:** clube de carros clássicos (Garagem 70).
- **Páginas:** início, cadastro de sócio, listagem/consulta.
- **Tecnologias:** HTML e CSS no visual; PHP em toda a lógica; JSON para guardar os dados.
- **ViaCEP:** o botão "Buscar CEP" envia o formulário para `buscar_cep.php`, que faz uma requisição cURL para `viacep.com.br/ws/CEP/json/`, decodifica o JSON e devolve o formulário com rua, bairro, cidade e UF preenchidos.
- **Modelos:** os HTML ficam em `templates/` com marcadores, que o PHP substitui com `str_replace`.
- **Gravação:** `salvar.php` valida, lê o JSON, adiciona o usuário e grava de volta.
- **Consulta:** `usuarios.php` lê o JSON e monta a tabela, com busca por nome, CPF ou cidade.
